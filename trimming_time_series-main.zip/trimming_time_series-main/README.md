# trimming_time_series

Time series data soemtimes require us to get reid of anomalies at the beginnning and at the end of the data this can be done by trimming the data set.
This is a sample code which can be used to trim the data I have used it trim the initial 10% of the data, this can be changed as per requirement but usually trimming the initial 5-10% is ideal.
