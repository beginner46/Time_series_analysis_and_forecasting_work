# Smoothing_time_series_moving_averages
This is my novice attempt at exploring time series smoothing, using various moving averages.
The dataset contains monthly beer production data.
Change the location for your dataset while importing the csv data to your colab notebook. Please don't blindly copy paste the code and run it. :)
